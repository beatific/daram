package org.beatific.daram.stuck;

public enum ThreadState {
	RUNNING, WAITING;
}
