package org.beatific.daram.stuck.check;

public abstract class StateConverter {

	public abstract void convert();
}
