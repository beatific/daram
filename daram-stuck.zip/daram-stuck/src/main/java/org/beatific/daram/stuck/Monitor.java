package org.beatific.daram.stuck;

public interface Monitor {

	public int getHoggingThreadsCount();
	public int getStuckThreadsCount();
	public int getRunningThreadCount();
	public int getThreadCount();
	
}
