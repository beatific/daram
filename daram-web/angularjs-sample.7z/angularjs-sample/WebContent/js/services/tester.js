'use strict';

define([], function () {

	return ['tester', '이거는 앵귤러 서비스의 value값']
})
