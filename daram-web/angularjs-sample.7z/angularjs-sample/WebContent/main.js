// main.js
var app = angular.module('myApp', [ 'ngGrid', 'ui.bootstrap']);
app.controller('MyCtrl', function($scope, $modal, $log) {
	$scope.myData = [ {
		name : "Moroni",
		age : 50
	}, {
		name : "Tiancum",
		age : 43
	}, {
		name : "Jacob",
		age : 27
	}, {
		name : "Nephi",
		age : 29
	}, {
		name : "Enos",
		age : 34
	} ];
	$scope.mySelections = [];
	$scope.gridOptions = {
		data : 'myData',
		selectedItems : $scope.mySelections,
		showSelectionCheckbox : true
	};

	$scope.deleteRow = function() {

		angular.forEach($scope.mySelections, function(rowItem) {
			if ($scope.myData.indexOf(rowItem) > 0)
				$scope.myData.splice($scope.myData.indexOf(rowItem), 1);
		});
	}

	dialog = $("#dialog-form").dialog({
		autoOpen : false,
		height : 300,
		width : 350,
		modal : true
//		buttons : {
//			"Create an account" : addUser,
//			Cancel : function() {
//				dialog.dialog("close");
//			}
//		},
//		close : function() {
//			form[0].reset();
//			allFields.removeClass("ui-state-error");
//		}
	});
	
	$scope.addRow = function (user) {
            $scope.user = user;
            $modal.open({
                templateUrl: 'myModalContent.html',
                backdrop: true,
                windowClass: 'modal',
                controller: function ($scope, $modalInstance, $log, user) {
                    $scope.user = user;
                    $scope.submit = function () {
                        $log.log('Submiting user info.');
                        $log.log(JSON.stringify(user));
                        $modalInstance.dismiss('cancel');
                    }
                    $scope.cancel = function () {
                        $modalInstance.dismiss('cancel');
                    };
                },
                resolve: {
                    user: function () {
                        return $scope.user;
                    }
                }
            });
        };
    
	
});