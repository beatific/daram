AngularJS + RequireJS Sample Project
====================================

In this example, I show how to get dynamically Template, Controller, Directive, Service, and Filter, by using RequireJS and AngularJS. Elements dynamically loaded, are rendered in ngView. 

I hope that you gets an insight about developing a basic stage of modularized large-scale Web application. 


## Libraries

1. Angular
2. RequireJS
3. RequireJS text


## License

MIT
